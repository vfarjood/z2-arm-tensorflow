#ifndef EIGEN_SPECIALFUNCTIONS_MODULE_H
#error "Please include unsupported/Eigen/SpecialFunctions instead of including headers inside the src directory directly."
#endif
