#ifndef EIGEN_SKYLINE_MODULE_H
#error "Please include unsupported/Eigen/Skyline instead of including headers inside the src directory directly."
#endif
